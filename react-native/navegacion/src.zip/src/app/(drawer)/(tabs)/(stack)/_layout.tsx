import {Stack, useNavigation} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
const StackLayout = ()=>{
    const navigation = useNavigation();
    const drawerNavegation = useNavigation() as any;

    const onHedaderLeftClick = (canGoBack?:boolean )=>{
        if(canGoBack){
            navigation.goBack();
            return;
        }
        if(typeof drawerNavegation?.openDrawer==='function'){
            drawerNavegation.openDrawer();
        }
    };
    return ( 
        <Stack
            screenOptions={{
                headerShadowVisible: false,
                contentStyle:{
                    backgroundColor:'white',
                },
                headerLeft:({canGoBack}) => (
                    <Ionicons
                        name={canGoBack? 'arrow-back-outline':'grid-outline'}
                        size={20}
                        style={{ marginRight: 20 }}
                        onPress={()=> onHedaderLeftClick(Boolean(canGoBack))}
                    />
                ),
            }}
        >
            <Stack.Screen
                name='home/index'
                options={{
                    title:'Inicio',
                }}
            />
            <Stack.Screen
                name='products/index'
                options={{
                    title:'Productos',
                }}
            />
            <Stack.Screen
                name='profile/index'
                options={{
                    title:'Perfil',
                }}
            />
            <Stack.Screen
                name='settings/index'
                options={{
                    title:'Ajustes Pantalla',
                }}
            />
        </Stack>
    );
};
export default StackLayout;
