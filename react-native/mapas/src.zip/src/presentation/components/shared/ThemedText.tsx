import { StyleSheet, Text, type TextProps } from 'react-native';
import { useThemeColor } from '@/presentation/hooks/useThemeColor';

export type ThemedTextProps = TextProps & {
    lightColor?:string;
    darkColor?: string;
    type?:'default' | 'title' | 'defaultSemiBold' | 'subtitle' | 'link';
};

export function ThemedText({
    style,
    lightColor,
    darkColor,
    type = 'default',
    ...rest
}: ThemedTextProps){
    const color = useThemeColor({light:lightColor, dark: darkColor}, 'text');

    return (
        <Text
            style={[
                {color},
                styles[type],
                style,
            ]}
            {...rest}
        />
    );
}

const styles = StyleSheet.create({
    default: { fontSize: 16, lineHeight: 24 },
    title: { fontSize: 32, fontWeight: '700', lineHeight: 38 },
    defaultSemiBold: { fontSize: 16, fontWeight: '600', lineHeight: 24 },
    subtitle: { fontSize: 20, fontWeight: '600', lineHeight: 28 },
    link: { fontSize: 16, lineHeight: 24, textDecorationLine: 'underline' },
});
